﻿using System;

namespace Ej3
{
	public class Empleo
	{
		//PARAMETROS
		private double iSueldo;
		private DateTime iFechaIngreso;

		//CONSTRUCTORES
		/// <summary>
		/// Inicializa una nueva instancia de la clase Empleo
		/// </summary>
		public Empleo (double pSueldo, DateTime pFechaIngreso)
		{
			this.iSueldo = pSueldo;
			this.iFechaIngreso = pFechaIngreso;
		}

		//PROPIEDADES
		/// <summary>
		/// Devuelve o asigna el valor de sueldo
		/// </summary>
		public double Sueldo {
			get { return this.iSueldo; }
			set { this.iSueldo = value; }
		}

		/// <summary>
		/// Devuelve o asigna el valor de la fecha de ingreso
		/// </summary>
		public DateTime FechaIngreso {
			get{ return this.iFechaIngreso; }
			set{ this.iFechaIngreso = value; }
		}



	}
}


﻿using System;
using System.Collections.Generic;

namespace Ej3
{
	public class GestorPrestamos
	{
		//ATRIBUTOS
		private IDictionary<TipoCliente,EvaluadorCompuesto> iEvaluadoresPorCliente = new Dictionary<TipoCliente, EvaluadorCompuesto> ();


		public GestorPrestamos ()
		{
			//creamos un evaluador compuesto y lo modificamos para cada tipo de cliente
			EvaluadorCompuesto evaluador = new EvaluadorCompuesto ();
			//como la antiguedad, sueldo minimo y edad necesarios son especificaciones  generales creamos un unico evaluador para c/u de estas
			EvaluadorAntiguedadLaboral evalAntiguedad = new EvaluadorAntiguedadLaboral (6);
			EvaluadorEdad evalEdad = new EvaluadorEdad (18, 75);
			EvaluadorSueldo evalSueldo = new EvaluadorSueldo (5000);
			//Tipo cliente NoCliente
			evaluador.AgregarEvaluador (evalAntiguedad);
			evaluador.AgregarEvaluador (evalEdad);
			evaluador.AgregarEvaluador (evalSueldo);
			evaluador.AgregarEvaluador (new EvaluadorMonto (20000));
			evaluador.AgregarEvaluador (new EvaluadorCantidadCuotas (12));
			iEvaluadoresPorCliente.Add (TipoCliente.NoCliente, evaluador);
			//Tipo cliente Cliente
			evaluador = new EvaluadorCompuesto ();
			evaluador.AgregarEvaluador (evalAntiguedad);
			evaluador.AgregarEvaluador (evalEdad);
			evaluador.AgregarEvaluador (evalSueldo);
			evaluador.AgregarEvaluador (new EvaluadorMonto (100000));
			evaluador.AgregarEvaluador (new EvaluadorCantidadCuotas (32));
			iEvaluadoresPorCliente.Add (TipoCliente.Cliente, evaluador);
			//Tipo cliente ClienteGold
			evaluador = new EvaluadorCompuesto ();
			evaluador.AgregarEvaluador (evalAntiguedad);
			evaluador.AgregarEvaluador (evalEdad);
			evaluador.AgregarEvaluador (evalSueldo);
			evaluador.AgregarEvaluador (new EvaluadorMonto (150000));
			evaluador.AgregarEvaluador (new EvaluadorCantidadCuotas (60));
			iEvaluadoresPorCliente.Add (TipoCliente.ClienteGold, evaluador);
			//Tipo cliente ClientePlatinum
			evaluador = new EvaluadorCompuesto ();
			evaluador.AgregarEvaluador (evalAntiguedad);
			evaluador.AgregarEvaluador (evalEdad);
			evaluador.AgregarEvaluador (evalSueldo);
			evaluador.AgregarEvaluador (new EvaluadorMonto (200000));
			evaluador.AgregarEvaluador (new EvaluadorCantidadCuotas (60));
			iEvaluadoresPorCliente.Add (TipoCliente.ClientePlatinum, evaluador);
		}

		//METODOS
		public bool EsValida (SolicitudPrestamo pSolicitudPrestamo)
		{
			return iEvaluadoresPorCliente [pSolicitudPrestamo.Cliente.TipoCliente].EsValida (pSolicitudPrestamo);
		}

	}
}


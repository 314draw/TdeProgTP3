﻿using System;

namespace Ej3
{
	public class Cliente
	{
		//ATRIBUTOS
		private string iNombre;
		private string iApellido;
		private DateTime iFechaNacimiento;
		private TipoCliente iTipoCliente = TipoCliente.NoCliente;
		private Empleo iEmpleo;

		//CONSTRUCTORES
		/// <summary>
		/// Inicializa una nueva isntncia de la clase cliente
		/// </summary>
		public Cliente (string pApellido, string pNombre, DateTime pFechaNacimiento, Empleo pEmpleo)
		{
			this.iNombre = pNombre;
			this.iApellido = pApellido;
			this.iFechaNacimiento = pFechaNacimiento;
			this.iEmpleo = pEmpleo;
			this.TipoCliente = TipoCliente.NoCliente;
		}

		//PROPIEDADES
		/// <summary>
		/// Devuelve o asigna el valor del nombre
		/// </summary>
		public string Nombre {
			get{ return this.iNombre; }
			set{ this.iNombre = value; }
		}

		/// <summary>
		/// Devuelve o asigna el valor del apellido
		/// </summary>
		public string Apellido {
			get{ return this.iApellido; }
			set{ this.iApellido = value; }
		}

		/// <summary>
		/// Devuelve o asigna el valor de la fecha de nacimiento
		/// </summary>
		public DateTime FechaNacimiento {
			get{ return this.iFechaNacimiento; }
			set{ this.iFechaNacimiento = value; }
		}

		/// <summary>
		/// Devuelve o asigna el valor de Empleo
		/// </summary>
		public Empleo Empleo {
			get{ return this.iEmpleo; }
			set{ this.iEmpleo = value; }
		}

		/// <summary>
		/// Devuelve o asigna el valor del tipo cliente
		/// </summary>
		public TipoCliente TipoCliente {
			get{ return this.iTipoCliente; }
			set{ this.iTipoCliente = value; }
		}
	}
}


﻿using System;

namespace Ej3
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Fachada wea = new Fachada ();
			wea.CrearSolicitud ();
		}
	}
}

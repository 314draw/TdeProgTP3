﻿using System;

namespace Ej3
{
	public class EvaluadorEdad : IEvaluador
	{
		//ATRIBUTOS
		private int iEdadMinima;
		private int iEdadMaxima;
		//CONSTRUCTOR
		/// <summary>
		/// Inicializa una nueva instancia de la clase EvaluadorEdad
		/// </summary>
		public EvaluadorEdad (int pEdadMinima, int pEdadMaxima)
		{
			this.iEdadMaxima = pEdadMaxima;
			this.iEdadMinima = pEdadMinima;
		}

		//METODOS
		/// <summary>
		/// Indica si la edad del cliente que realiza la solicitud es la correspondiente
		/// </summary>
		public bool EsValida (SolicitudPrestamo pSolicitudPrestamo)
		{
			DateTime pFecha = pSolicitudPrestamo.Cliente.FechaNacimiento;
			int pEdad = DateTime.Now.Year - pFecha.Year;
			if ((pFecha.Month > DateTime.Now.Month) || (pFecha.Month == DateTime.Now.Month && pFecha.Day > DateTime.Now.Day)) {
				pEdad--;
			}
			if (pEdad > this.iEdadMinima && pEdad < this.iEdadMaxima) {
				return true;
			} else {
				return false;
			}
		}


	}
}


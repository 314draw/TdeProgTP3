﻿using System;

namespace aSugarRushtp3
{
	public class Gestor
	{
		public Gestor ()
		{
		}
	}
}


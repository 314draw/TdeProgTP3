﻿using System;

namespace Ej3
{
	public class EvaluadorCantidadCuotas : IEvaluador
	{
		//ATRIBUTOS
		private int iCantidadMaximaCuotas;

		//CONSTRUCTORES
		/// <summary>
		/// Inicializa una nueva instancia de la clase EvaluadorCantidadCuotas
		/// </summary>
		public EvaluadorCantidadCuotas (int pCantidadCuotas)
		{
			this.iCantidadMaximaCuotas = pCantidadCuotas;
		}

		//METODOS
		/// <summary>
		/// Indica si la cantidad de cuotas de la solicitud de prestamo no sobrepasa la correspondiente al tipo de cliente
		/// </summary>
		public bool EsValida (SolicitudPrestamo pSolicitudPrestamo)
		{
			if (pSolicitudPrestamo.CantidadCuotas <= this.iCantidadMaximaCuotas) {
				return true;
			} else {
				return false;
			}
		}

	}
}


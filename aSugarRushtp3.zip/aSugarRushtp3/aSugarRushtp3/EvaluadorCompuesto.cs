﻿using System;
using System.Collections.Generic;

namespace Ej3
{
	public class EvaluadorCompuesto : IEvaluador
	{
		//ATRIIBUTOS
		List<IEvaluador> iEvaluadores = new List<IEvaluador> ();

		public EvaluadorCompuesto ()
		{
		}

		//METODOS
		/// <summary>
		/// Indica si una solicitud de prestamo cumple con todos los requerimientos epecificados por sus evaluadores
		/// </summary>
		public bool EsValida (SolicitudPrestamo pSolicitudPrestamo)
		{
			int i = 0;
			bool validez = true;
			while (validez && i <= iEvaluadores.Capacity) {
				validez = iEvaluadores [i].EsValida (pSolicitudPrestamo);
				i++;
			}
			return validez;
		}

		/// <summary>
		/// Agrega un nuevo evaluador a la lista de evaluadores.
		/// </summary>
		public void AgregarEvaluador (IEvaluador pEvaluador)
		{
			iEvaluadores.Add (pEvaluador);
		}


	}
}


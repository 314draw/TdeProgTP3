﻿using System;

namespace Ej3
{
	public class EvaluadorSueldo : IEvaluador
	{
		//ATRIBUTOS
		private double iSueldoMinimo;

		//CONSTRUCTORES
		/// <summary>
		/// Inicializa una nueva instancia de la clase EvaluadorSueldo
		/// </summary>
		public EvaluadorSueldo (double pSueldoMinimo)
		{
			this.iSueldoMinimo = pSueldoMinimo;
		}

		//METODOS
		/// <summary>
		/// Indica si el sueldo del cliente de la solicitud de prestamo corresponde con el minimo correspondiente según el tipo de cliente
		/// </summary>
		public bool EsValida (SolicitudPrestamo pSolicitudPrestamo)
		{
			if (pSolicitudPrestamo.Cliente.Empleo.Sueldo >= this.iSueldoMinimo) {
				return true;
			} else {
				return false;
			}
		}
	}
}


﻿using System;

namespace Ej3
{
	public class EvaluadorMonto : IEvaluador
	{
		//ATRIBUTOS
		private double iMontoMaximo;

		//CONSTRUCTORES

		/// <summary>
		/// Inicializa una nueva instancia de la clase EvaluadorMonto
		/// </summary>
		public EvaluadorMonto (double pMontoMaximo)
		{
			this.iMontoMaximo = pMontoMaximo;
		}

		//METODOS
		/// <summary>
		/// Indica si el monto de la solicitud de prestamo corresponde con el monto correspondiente al tipo de cliente
		/// </summary>
		public bool EsValida (SolicitudPrestamo pSolicitudPrestamo)
		{
			if (pSolicitudPrestamo.Monto <= this.iMontoMaximo) {
				return true;
			} else {
				return false;
			}
		}
	}
}


﻿using System;

namespace Ej3
{
	public interface IEvaluador
	{
		bool EsValida (SolicitudPrestamo pSolicitud);
	}
}


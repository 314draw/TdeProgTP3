﻿using System;

namespace Ej3
{
	public enum TipoCliente
	{
		NoCliente = 0,
		Cliente = 1,
		ClienteGold = 2,
		ClientePlatinum = 3
	}
}


﻿using System;

namespace Ej3
{
	public class EvaluadorAntiguedadLaboral : IEvaluador
	{
		//ATRIBUTOS
		private int iAntiguedadMinima;
		//CONSTRUCTORES
		/// <summary>
		/// Inicializa una nueva instancia de la clase EvaluadorAntiguedadLaboral
		/// </summary>
		public EvaluadorAntiguedadLaboral (int pAntiguedadMinima)
		{
			this.iAntiguedadMinima = pAntiguedadMinima;
		}

		//METODOS
		/// <summary>
		/// Indica si la antiguedad laboral del cliente que realiza la solicitud supera la antiguedad minima necesaria
		/// </summary>
		public bool EsValida (SolicitudPrestamo pSolicitud)
		{
			DateTime pFechaActual = DateTime.Today;
			if ((pFechaActual.Subtract (pSolicitud.Cliente.Empleo.FechaIngreso)).TotalDays > (this.iAntiguedadMinima * 30)) {
				return true;
			} else {
				return false;
			}
		}
	}
}


﻿using System;

namespace Ej3
{
	public class SolicitudPrestamo
	{
		//PARAMETROS
		private double iMonto;
		private int iCantidadCuotas;
		private Cliente iCliente;

		//CONSTRUCTORES
		/// <summary>
		/// Inicializa una nueva instancia de la clase SolicitudPrestamo
		/// </summary>
		public SolicitudPrestamo (Cliente pCliente, double pMonto, int pCantidadCuotas)
		{
			this.iMonto = pMonto;
			this.iCantidadCuotas = pCantidadCuotas;
			this.iCliente = pCliente;
		}

		//PROPIEDADES
		/// <summary>
		/// Devuelve o asigna el valor del monto
		/// </summary>
		public double Monto {
			get{ return this.iMonto; }
			set{ this.iMonto = value; }
		}

		/// <summary>
		/// Devuelve o asigna la cantidad de cuotas
		/// </summary>
		/// <value><c>true</c> if this instance cantidad cuotas; otherwise, <c>false</c>.</value>
		public int CantidadCuotas {
			get{ return this.iCantidadCuotas; }
			set{ this.iCantidadCuotas = value; }
		}

		/// <summary>
		/// Devuelve o asigna el cliente
		/// </summary>
		public Cliente Cliente {
			get{ return this.iCliente; }
			set{ this.iCliente = value; }
		}
	}
}


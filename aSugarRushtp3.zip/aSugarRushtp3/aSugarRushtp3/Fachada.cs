﻿using System;

namespace Ej3
{
	public class Fachada
	{
		//ATRIBUTOS


		//CONSTRUCTORES
		public Fachada ()
		{
		}

		//METODOS
		/// <summary>
		/// Crear un nuevo cliente 
		/// </summary>
		public Cliente CrearCliente ()
		{
			String pFecha, pNombre, pApellido;
			DateTime dFechaNacimiento, dFechaIngreso;
			int op;
			Console.Clear ();
			Console.WriteLine ("------------Datos del la persona------------");
			Console.Write ("Ingrese apellido: ");
			pApellido = Console.ReadLine ();
			Console.Write ("Ingrese nombre: ");
			pNombre = Console.ReadLine ();
			do {
				Console.Write ("Ingrese fecha de nacimiento: ");
				pFecha = Console.ReadLine ();
			} while (!DateTime.TryParse (pFecha, out dFechaNacimiento));
			Console.WriteLine ("La persona es (0) no cliente, (1) cliente, (2) cliente gold (3) cliente platinum");
			do {
				op = Convert.ToInt16 (Console.ReadLine ());
			} while (!(op >= 0 || op <= 3));
			double pSueldo;
			Console.WriteLine ("------------Datos del empleo------------");
			Console.Write ("Ingrese el sueldo: ");
			pSueldo = Convert.ToDouble (Console.ReadLine ());
			do {
				Console.Write ("Ingrese fecha de ingreso: ");
				pFecha = Console.ReadLine ();
			} while (!DateTime.TryParse (pFecha, out dFechaIngreso));
			Empleo pEmpleo = new Empleo (pSueldo, dFechaIngreso);
			Cliente pCliente = new Cliente (pApellido, pNombre, dFechaNacimiento, pEmpleo);
			switch (op) {
			case 0:
				pCliente.TipoCliente = TipoCliente.NoCliente;
				break;
			case 1:
				pCliente.TipoCliente = TipoCliente.Cliente;
				break;
			case 2:
				pCliente.TipoCliente = TipoCliente.ClienteGold;
				break;
			case 3:
				pCliente.TipoCliente = TipoCliente.ClientePlatinum;
				break;
			}
			return pCliente;
		}

		/// <summary>
		/// Consulta al gestor de rpestamos si la solicitud ingresada es valida
		/// </summary>
		public bool ValidarSolicitud (SolicitudPrestamo pSolicitudPrestamo)
		{
			GestorPrestamos pGestorPrestamos = new GestorPrestamos ();
			return pGestorPrestamos.EsValida (pSolicitudPrestamo);
		}

		/// <summary>
		/// Crea una nueva solicitud si está cuenta con sus requisitos correspondientes
		/// </summary>
		public void CrearSolicitud ()
		{
			SolicitudPrestamo pSolicitudPrestamo;
			do {				
				Cliente pCliente = this.CrearCliente ();
				double pMonto;
				int pCantidadCuotas;

				Console.WriteLine ("------------Datos del prestamo------------");
				Console.Write ("Ingrese el monto: ");
				pMonto = Convert.ToDouble (Console.ReadLine ());
				Console.Write ("Ingrese la cantidad de cuotas: ");
				pCantidadCuotas = Convert.ToInt32 (Console.ReadLine ());
				pSolicitudPrestamo = new SolicitudPrestamo (pCliente, pMonto, pCantidadCuotas);
				if (this.ValidarSolicitud (pSolicitudPrestamo)) {
					Console.WriteLine ("La solicitud es válida");
				} else {
					Console.WriteLine ("Error la solicitud ingresada no es válida");
				}
			} while (!this.ValidarSolicitud (pSolicitudPrestamo));
		}

	}
}

